## Solving the Model
```@autodocs
Modules = [GenX]
Pages = ["solve_model.jl"]
```