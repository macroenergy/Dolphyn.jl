# configure multi stage inputs
```@autodocs
Modules = [GenX]
Pages = ["configure_multi_stage_inputs.jl"]
```
