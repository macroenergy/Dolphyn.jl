# load generators data multi stage
```@autodocs
Modules = [GenX]
Pages = ["load_generators_data_multi_stage.jl"]
```
