# Storage All
```@autodocs
Modules = [GenX]
Pages = ["storage_all.jl"]
```