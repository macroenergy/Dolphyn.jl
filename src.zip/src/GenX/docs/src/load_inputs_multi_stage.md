# load inputs multi stage
```@autodocs
Modules = [GenX]
Pages = ["load_inputs_multi_stage.jl"]
```
