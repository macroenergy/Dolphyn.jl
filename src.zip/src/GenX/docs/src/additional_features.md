# Additional Features

## Modeling to Generate Alternatives
```@autodocs
Modules = [GenX]
Pages = ["modeling_to_generate_alternatives.jl"]
```
## Method of Morris
```@autodocs
Modules = [GenX]
Pages = ["method_of_morris.jl"]
```
