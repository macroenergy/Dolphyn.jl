using DataFrames
using LinearAlgebra
df1 = DataFrame(RepPeriods =[1,2], ESR_Price = [1,3])