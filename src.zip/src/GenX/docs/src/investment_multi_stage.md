# Investment multi stage
```@autodocs
Modules = [GenX]
Pages = ["investment_multi_stage.jl"]
```

# Storage multi stage
```@autodocs
Modules = [GenX]
Pages = ["storage_multi_stage.jl"]
```

# Transmission multi stage
```@autodocs
Modules = [GenX]
Pages = ["transmission_multi_stage.jl"]
```