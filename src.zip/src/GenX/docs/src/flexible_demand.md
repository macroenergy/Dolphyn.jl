# Flexible Demand
```@autodocs
Modules = [GenX]
Pages = ["flexible_demand.jl"]
```